################################################################################
# IS-A Relationship Review
#
# Purpose: Demonstration of is-a relationships, abstract classes.
# Author: Kevin Browne
# Contact: brownek@mcmaster.ca
#
################################################################################

from abc import ABC, abstractmethod

# The base class vehicle is also an abstract class with an abstract method, 
# which means we can't instantiate an instance of it.  
class Vehicle(ABC):
    
    def __init__(self, model, wheels, top_speed):
        self.model = model
        self.wheels = wheels
        self.top_speed = top_speed
        
    def travel_time(self, distance):
        return distance / self.top_speed
        
    # We MUST override abstract method print_details in any derived classes
    @abstractmethod
    def print_details(self):
        pass

# Car is a derived class of vehicle
class Car(Vehicle):
    
    def __init__(self, model, top_speed):
        super().__init__(model, 4, top_speed)
        
    def print_details(self):
        print(self.model, "with", self.wheels, "wheels", "and top speed of", 
              self.top_speed, "km/h")
        
# Bike is also a derived class of Vehicle
class Bike(Vehicle):
    
    def __init__(self, model, color):
        self.color = color 
        super().__init__(model, 2, 40)
        
    def print_details(self):
        print(self.color, self.model, "with", self.wheels, "wheels", 
              "and top speed of", self.top_speed, "km/h")    
        
trek_bike = Bike("Trek Bicycle", "red")
mustang = Car("Mustang", 240)

print("Mustang Car Travel Time 100km:",  mustang.travel_time(100), "hours")
print("Trek Bike Travel Time 100km:",  trek_bike.travel_time(100), "hours" )

# mustang.print_details()
# trek_bike.print_details()

# Can't instantite an abtract class!
# generic_vehicle = Vehicle("Unicylce", 1, 5)
  
vehicles = [trek_bike, mustang]

# Polymorphism
for vehicle in vehicles:
    vehicle.print_details()