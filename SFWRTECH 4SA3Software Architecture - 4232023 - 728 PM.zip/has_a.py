################################################################################
# Has-A Relationship Review
#
# Purpose: Demonstration of has-a relationships.
# Author: Kevin Browne
# Contact: brownek@mcmaster.ca
#
################################################################################

class Doctor:
    
    def __init__(self,name):
        self.name = name 
        
class Hospital:
    
    def __init__(self):
        self.__doctors = []
        
    def add_doctor(self, doctor):
        self.__doctors.append(doctor)
        
    def print_doctors(self):
        for doctor in self.__doctors:
            print(doctor.name)
            
            
doctor_diana = Doctor("Diana Smith")
doctor_nageeb = Doctor("Nageeb Ali")
doctor_julia = Doctor("Julia Black")

st_joes = Hospital()
st_joes.add_doctor(doctor_diana)
st_joes.add_doctor(doctor_nageeb)
st_joes.add_doctor(doctor_julia)

st_joes.print_doctors()
